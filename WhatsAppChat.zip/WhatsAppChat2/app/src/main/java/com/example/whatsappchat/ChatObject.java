package com.example.whatsappchat;

public class ChatObject {
    public String getChatId() {
        return " ";
    }
}
