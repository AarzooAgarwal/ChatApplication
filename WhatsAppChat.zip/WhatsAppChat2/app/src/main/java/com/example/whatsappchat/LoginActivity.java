package com.example.whatsappchat;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.AbstractMap;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.concurrent.TimeUnit;

public class LoginActivity extends AppCompatActivity {
    private EditText mphonenumber, mcode;
    private Button msend;
    private DatabaseReference mDatabase;
    private PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks;
    String mVerificationId;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //UserIsLoggedIn();
        mphonenumber = findViewById(R.id.phonenumber);
        msend = findViewById(R.id.code);
        mcode = findViewById(R.id.send);
        msend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mVerificationId != null)
                    verifyphonenumberwithcode();
                else
                    startphonenumberverification();
            }
        });
        mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
            @Override
            // signing in information
            public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {
                //signin function
                signInWithPhoneAuthCredential(phoneAuthCredential);
            }

            @Override
            public void onVerificationFailed(@NonNull FirebaseException e) {
            }

            @Override
            public void onCodeSent(@NonNull String verificationId, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                super.onCodeSent(verificationId, forceResendingToken);
                mVerificationId = verificationId;
                msend.setText("Verify code");

            }
        };
    }

    private void verifyphonenumberwithcode() {
        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(mVerificationId, mcode.getText().toString());
        signInWithPhoneAuthCredential(credential);
    }

    private void signInWithPhoneAuthCredential(PhoneAuthCredential phoneAuthCredential) {

        //FirebaseAuth.getInstance().signInWithCredential(phoneAuthCredential).addOnCompleteListener(this, (task));
        //public void onComplete(Task < AuthResult > task){
          //  if (task.isSuccessful())
                final FirebaseUser user=FirebaseAuth.getInstance().getCurrentUser();
                if(user!=null){
                    final DatabaseReference mUserDB= FirebaseDatabase.getInstance().getReference().child("user").child(user.getUid());
                    mUserDB.addListenerForSingleValueEvent(new ValueEventListener(){

                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            if(!dataSnapshot.exists()){
                                Map<String,Object>UserMap=new HashMap<>();
                                Map<String, Object> userMap = null;
                                userMap.put("phone",user.getPhoneNumber());
                                userMap.put("name",user.getPhoneNumber());
                                mUserDB.updateChildren(userMap);
                            }
                        }
                        //UserIsLoggedIn();
                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });
                }


    };

    //checks whether the user is different or not
    private void UserIsLoggedIn() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            startActivity(new Intent(getApplicationContext(), MainPageActivity.class));
            finish();
            return;
        }
    }

    private void startphonenumberverification() {
        PhoneAuthProvider.getInstance().verifyPhoneNumber(mphonenumber.getText().toString(), 60, TimeUnit.SECONDS,
                this, mCallbacks);

    }
}

