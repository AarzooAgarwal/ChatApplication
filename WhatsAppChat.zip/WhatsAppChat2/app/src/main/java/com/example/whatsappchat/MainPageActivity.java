package com.example.whatsappchat;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;

import Chat.ChatListAdapter;

public class MainPageActivity extends AppCompatActivity {
    private RecyclerView mChatList;
    private UserListAdapter mChatListAdapter;
    private RecyclerView.LayoutManager mChatListLayoutManager;
    ArrayList<UserClass> ChatList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_page);
        Button mlogout=findViewById(R.id.logout);
        Button mfinduser=findViewById(R.id.findUser);
        mlogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),FindUserActivity.class));
            }
        });
        mlogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                Intent intent=new Intent(getApplicationContext(), LoginActivity.class);
                intent.addFlags(intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
                return;
            }
        });
        getpermissions();
        initializeRecyclerView(ChatList);
    }
    private void getpermissions(){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(new String[]{Manifest.permission.WRITE_CONTACTS,Manifest.permission.READ_CONTACTS},1);
        }

    }
    @SuppressLint("WrongConstant")
    private void initializeRecyclerView(ArrayList<UserClass> chatList) {
        mChatList=findViewById(R.id.chatList);
        //mUserList=setNestedScrollingEnabled(false);
        mChatListLayoutManager=new LinearLayoutManager(getApplicationContext(), LinearLayout.VERTICAL,false);
        mChatList.setLayoutManager(mChatListLayoutManager);
        mChatListAdapter= new UserListAdapter(ChatList);
        mChatListAdapter.setAdapter(mChatListAdapter);
    }
}
