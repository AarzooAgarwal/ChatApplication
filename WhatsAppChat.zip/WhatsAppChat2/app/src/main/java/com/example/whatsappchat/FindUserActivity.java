package com.example.whatsappchat;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.solver.widgets.Snapshot;
import androidx.recyclerview.widget.LinearLayoutManager;
import java.util.Objects;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SnapHelper;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.telephony.TelephonyManager;
import android.widget.LinearLayout;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class FindUserActivity extends AppCompatActivity {
    private RecyclerView mUserList;
    private UserListAdapter mUserListAdapter;
    private RecyclerView.LayoutManager mUserListLayoutManager;
    ArrayList<UserClass> UserList,ContactList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_user);
        ContactList=new ArrayList<>();
        UserList=new ArrayList<>();
        initializeRecyclerView();
        getcontactlist();
    }
    private void getcontactlist(){
        String ISOprefix=getCountryISO();
        Cursor phones=getContentResolver().query((ContactsContract.CommonDataKinds.Phone.CONTENT_URI),
                null,null,null,null);
        while(phones.moveToNext()){
            String phone=phones.getString(phones.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
            String name=phones.getString(phones.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
            phone=phone.replace(" -"," ");
            phone=phone.replace(" "," ");
            phone=phone.replace(" )"," ");
            phone=phone.replace(" ("," ");
            if(!String.valueOf(phone.charAt(0)).equals("+"))phone=ISOprefix+phone;
            UserClass mContact=new UserClass(" ",name,phone);
            ContactList.add(mContact);
            getUserDetails(mContact);
        }
    }

    private void getUserDetails(final UserClass mContact) {
        DatabaseReference mUserDB= FirebaseDatabase.getInstance().getReference().child("user");
        Query query=mUserDB.orderByChild("phone").equalTo(mContact.getPhone());
        query.addListenerForSingleValueEvent(
                new ValueEventListener(){
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot){
                        if(dataSnapshot.exists()){
                            String phone=" ";
                            String name=" ";
                            for(DataSnapshot childSnapshot:dataSnapshot.getChildren()){
                                if(childSnapshot.child("phone").getValue()!=null)
                                    phone=childSnapshot.child("phone").getValue().toString();
                                if(childSnapshot.child("name").getValue()!=null)
                                    name=childSnapshot.child("name").getValue().toString();
                                UserClass mUser=new UserClass(childSnapshot.getKey(),name,phone);
                                if(name.equals(phone)){
                                    for(UserClass mContactIterartor:ContactList){
                                        if(mContactIterartor.getPhone().equals(mUser.getPhone())){
                                            mUser.setName(mContactIterartor.getName());
                                        }
                                    }
                                }
                                UserList.add(mUser);
                                mUserListAdapter.notifyDataSetChanged();
                                return;
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                }
        );
    }

    private String getCountryISO(){
        String iso=null;
        @SuppressLint("ServiceCast") TelephonyManager telephonyManager=(TelephonyManager) getApplicationContext().getSystemService(getApplicationContext().TELECOM_SERVICE);
        if(telephonyManager.getNetworkCountryIso()!=null)
            if(!telephonyManager.getNetworkCountryIso().toString().equals(" "))
                iso=telephonyManager.getNetworkCountryIso().toString();
        return CountryToPhonePrefix.getPhone(iso);
    }
    @SuppressLint("WrongConstant")
    private void initializeRecyclerView() {
        mUserList=findViewById(R.id.UserList);
        //mUserList=setNestedScrollingEnabled(false);
        mUserListLayoutManager=new LinearLayoutManager(getApplicationContext(), LinearLayout.VERTICAL,false);
        mUserList.setLayoutManager(mUserListLayoutManager);
        mUserListAdapter=new UserListAdapter(UserList);
        mUserListAdapter.setAdapter(mUserListAdapter);
    }
}
