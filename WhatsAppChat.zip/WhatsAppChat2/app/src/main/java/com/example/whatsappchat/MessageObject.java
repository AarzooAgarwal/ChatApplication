package com.example.whatsappchat;

import java.util.ArrayList;

public class MessageObject {
    public MessageObject(String key, String creatorID, String text, ArrayList<String> mediaUrlList) {
    }
}
