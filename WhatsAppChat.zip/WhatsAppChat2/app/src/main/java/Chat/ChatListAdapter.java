package Chat;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.whatsappchat.R;
import com.example.whatsappchat.UserClass;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class ChatListAdapter extends RecyclerView.Adapter<ChatListAdapter.UserListViewHolder> {
    ArrayList<UserClass> ChatList;
    public ChatListAdapter(ArrayList<UserClass> UserList){
        this.ChatList=UserList;
    }

    @NonNull
    @Override
    public ChatListAdapter.UserListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType){
        View LayoutView= LayoutInflater.from(parent.getContext()).inflate(R.layout.item_user,null,false);
        RecyclerView.LayoutParams lp=new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);
        LayoutView.setLayoutParams(lp);
        UserListViewHolder rcv=new
        UserListViewHolder(LayoutView);
        return rcv;
    }

    //@Override
    public void onBindViewHolder(@NonNull ChatListAdapter.UserListViewHolder holder, final int position) {
        holder.mname.setText(ChatList.get(position).getName());
        holder.mphone.setText(ChatList.get(position).getPhone());
        holder.mlayout.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                String key= FirebaseDatabase.getInstance().getReference().child("chat").push().getKey();
                FirebaseDatabase.getInstance().getReference().child("user").child(FirebaseAuth.getInstance().getUid()).
                        child("chat").child(key).setValue(true);
                FirebaseDatabase.getInstance().getReference().child("user").child(ChatList.get(position).getUid()).
                        child("chat").child(key).setValue(true);
            }
        });
    }




    //@Override
    //public void onBindViewHolder(@NonNull UserListViewHolder holder, final int position) {

    @Override
    public int getItemCount() {
        return ChatList.size();
    }

    public void setAdapter(com.example.whatsappchat.UserListAdapter mUserListAdapter) {
    }

    public class UserListViewHolder extends RecyclerView.ViewHolder{
        public TextView mname,mphone,mlayout;
        public UserListViewHolder(View view){
            super(view);
            mname=view.findViewById(R.id.name);
            mphone=view.findViewById(R.id.phone);
            mlayout=view.findViewById(R.id.layout);

        }
    }
}
