package Chat;

public class ChatObjectJava {
    private String ChatId;
    public ChatObjectJava(String ChatId){
        this.ChatId=ChatId;
    }
    public  String getChatId(){
        return ChatId;
    }
}


